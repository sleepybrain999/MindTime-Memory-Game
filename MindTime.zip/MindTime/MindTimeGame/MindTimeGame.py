import subprocess
import threading
import sys

def run_game():
    subprocess.run(["python", "match.py"])

def run_video_stream():
    subprocess.run(["python", "video_stream.py"])

if __name__ == "__main__":
    # Start the game in a separate thread
    game_thread = threading.Thread(target=run_game)
    game_thread.start()

    # Run the video stream in the main thread
    run_video_stream()
    
    # Wait for the game thread to finish
    game_thread.join()

    sys.exit()