
import cv2
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()

    if not ret:
        print("Failed to capture frame")
        break

    cv2.imshow("Video Stream", frame)

   
    key = cv2.waitKey(1)
    
    # Check if the user pressed the 'q' key or closed the window
    if key == ord("q") or cv2.getWindowProperty("Video Stream", cv2.WND_PROP_VISIBLE) < 1:
        break

cap.release()
cv2.destroyAllWindows()